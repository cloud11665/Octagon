# Octagon.

stopsign